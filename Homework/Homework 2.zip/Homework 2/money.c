#include <stdio.h>

float overall_revenue(FILE *f1)
{
    float revenue = 0.0;
    float value;
    while (fscanf(f1, "%f", &value) != EOF) {
        revenue += value;
    }
    return revenue;
}

float balance(FILE *f1)
{
    float balance = 0.0;
    float value;
    while (fscanf(f1, "%f", &value) != EOF) {
        balance += value;
    }
    return balance;
}