#include <stdio.h>
float overall_revenue(FILE *f1);
float balance(FILE *f1);